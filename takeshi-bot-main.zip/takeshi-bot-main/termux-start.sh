pkg upgrade -y && pkg update -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && chmod -R 777 ./* && npm start
